/* 
 * File:   DC.c
 * Author: mleziva
 *
 * Created on  2024
 */
#define TEST
#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
  #pragma config FOSC = XT
  #pragma config PWRTE = ON
  #pragma config WDTE = ON 
  #pragma config CP = ALL
#pragma config LVP = OFF
#pragma config BOREN = ON 
#pragma config CPD = OFF
#pragma config WRT = OFF

 // outputs
#define RESERVE     RC0
#define PWM_REGI    RC1	
#define RES2        RC2
#define RES3        RC3	
#define LED_PAUSA   RC4
#define COUNTER     RC5
    #define LEDZ        RC6
    #define LEDC        RC7
    #define LEDPORT PORTC 
    #define LEDORAN 0xc0 
#define LEDONEG (~LEDORAN) 
#define I30A     RB0
#define I60A     RB1
#define I90A     RB2
#define NAB1     RB3
#define NAB2     RB4
#define Pb_Li    RB5

//analog input channels
#define REGBAT    0
#define MERBAT    1

        //stavy programu
#define INI         0
#define READY      10
#define VYBIJI     20
#define VYBITA     30
#define NABIJI     40
#define NABITA     50
#define PAUSA      15


            //napeti

#define KBAT         (0x10000/(10*10*5))
#define UBLiVYB      (KBAT*95)// 10,0
#define UBPbVYB       (KBAT*87)// 9,3V
#define UBLiNAB      (KBAT*133)// 14,0V
#define UBPbNAB      (KBAT*134)// 14,0V



        //casy 1bit=2ms
#ifndef TEST
    #define TpLiVYB    (500*60*20)      //20min
    #define TpLiNAB    (500*60*30)      //30min.
    #define TpPbVYB    (500*60*10)      //10min.
    #define TpPbNAB    (500*60*60)      //60min.
#else
    #define TpLiVYB    (500*20)         //20sec
    #define TpLiNAB    (500*20)         //20sec
    #define TpPbVYB    (500*20)         //20sec
    #define TpPbNAB    (500*20)         //20sec
#endif

#define PULSEC      250            //500ms
#define SEC         500            //1s
#define DVESEC      1000            //2s
#define DESETSEC    5000            //10s
#define TIMINC      100            //200ms
#define PWMAX        251            //

//filtered dig.inputs
union
{
    uint8_t B;
    struct
    {
      uint8_t      : 1;    
      uint8_t       :1; 
      uint8_t START: 1; 
      uint8_t I30_60_90:1; 
      uint8_t NAB1_2:1; 
      uint8_t PAUSE: 1; 
      uint8_t Li_Pb: 1; 
      uint8_t       : 1; 
    };
} ai,  fil, fh,fd;  //vzorek, filtr, hrany vstupu

union
{
    uint8_t B;
    struct
    {
      uint8_t Iout : 3;    
      uint8_t NABout:2; 
    };
} porto;
        //16bit. slovo w=[H,L]
typedef union
{
    uint16_t w;
    struct
    {
        uint8_t L;
        uint8_t H;
    }  ;
}word;

_Bool PAUSE, LONGSTART, REDORA;// priznak pauza, dlouhe tlacitko start, stridani LED
_Bool ULOW, LBLIK, QBLIK, AKCEL_SEP, VYB;
uint8_t in[8], set, res, film ;//prom. fitru
uint8_t step,stepold, k, j ,lt,prodleva,startime;//krok programu, predch. krok,.., citac prodlevy 50 ms 
uint8_t plyn,blik,ivyb,nab,dialvyb;//prepoctena hod. akc.do  pwm,  odmer. blik.LED, stav brzd. pedalu, vybijeci proud po 30A, pocet sepnutych nabijecek
uint16_t baterie,regulin,baterfil, regulfil,zpozdeni, tstart, tcount,Uvyb,Unab;//;
uint32_t delay, Tpvyb, Tpnab;

uint16_t adc_read(unsigned char channel)//mereni Adc
{  
ADCON0 = (channel << 3) + 0x41;		// !T enable ADC,  osc.8*Tosc
 //DelayUs(20); 
 j=3;
 while(j)
     j--;
 GO_DONE = 1;
 while(GO_DONE)
 continue;	// wait for conversion complete
 return (((uint16_t)ADRESH)<<8) + ADRESL;
}

void adc_filter(uint16_t *act,uint16_t *filt)//filtr hodnot, merenych Adc
{
    int16_t ax= (int16_t)((*act)>>4) - (int16_t)((*filt)>>4);
    *filt += (uint16_t)ax; 
}


int main(int argc, char** argv)
{
        //config
   PORTC=0x0; 
   TRISC=0x0;     //outs enable
   PORTB= 0b00000000;
   TRISB= 0b11100000;//
   OPTION_REGbits.nRBPU=0;// pull up
   ADCON1bits.ADFM= 0;//left just. ADC
   ADCON1bits.PCFG=4;
   step=INI;
    //init dig. filters
   ADCON1bits.PCFG=0x0e;
   ai.B= PORTA;
   ADCON1bits.PCFG=0x04;
   ai.Li_Pb= Pb_Li;
   film= ai.B; //inverted inputs
   for (j=0; j<8; j++)
   {
           in[j]= film;
   }
   fil.B= film;
   fh.B=0;
   
    //init adc's
   baterfil= adc_read(REGBAT);
   regulfil= adc_read(MERBAT);
   CCPR2L=0;
   CCPR1L=0;
  // CCP2CONbits.CCP2M= 0xf;//PWM RC1 
  // CCP1CONbits.CCP1M= 0xf;//PWM RC2 
   T2CONbits.T2CKPS= 1;//prescaller=4
   PR2=PWMAX-1;   //250*4=1000us TMR2 period
  // T2CONbits.TOUTPS=1;//postscalller=2, T2IF 2ms
   T2CONbits.TMR2ON= 1;//start T2   
   TMR1=-2000;
   TMR1ON=1;
   //infinited cycle
   while(1)
   {    
     CLRWDT();  //clear watchdog timer
     if(TMR1IF)//2ms cyklus
 //    if(TMR2IF)//2ms cyklus
     {
         TMR1=-2000;
         TMR1IF =0;
                   //digital filters Td=8*2=16ms
       k++;
       k %=8;
       ADCON1bits.PCFG=0x0e;
       ai.B= PORTA;
       ADCON1bits.PCFG=0x04;
       ai.Li_Pb= Pb_Li;
       in[k]= ai.B;
       set=0xff;
       res=0;
       for (j=0; j<8; j++)
       {
           set &= in[j];   //all 8 last 5ms samples must be 1 for set to 1  
           res |= (in[j]); //all 8 last 5ms samples must be 0 for reset to 0  
       }
       fil.B= ((~film) & set) | (film & (res));
       fh.B= ((~film) & fil.B ); //rise edge 
       film= fil.B;// memory     
       regulin= adc_read(REGBAT);
       baterie= adc_read(MERBAT);
       adc_filter( &regulin,&regulfil);
       adc_filter( &baterie,&baterfil);
       if(blik==0)REDORA= !REDORA;
       LBLIK= ((blik & 0x80) != 0);//priznak blikani
       QBLIK= ((blik & 0x20) != 0);//priznak blikani 4x rychleji
       blik++;
       
                        //prodleva po startu
       if(startime< TIMINC)
       {
         startime++;
         step= INI;
       }     
       CCPR2L=regulin>>8;//t
       CCPR1L=CCPR2L;
                //vyber akce dle aktualniho stavu
       if(COUNTER)
       {
           tcount++;
           if(tcount > PULSEC)
               COUNTER = 0;
       }
       if(step > READY)
       {
           if(fh.PAUSE)
           {
             if(step==PAUSA)
             {
                 step= stepold;
                 LED_PAUSA = 0;
                 porto.B= PORTB;
                 porto.Iout=dialvyb;
                 PORTB= porto.B;

             }
             else
             {
                 stepold= step;
                 porto.B= PORTB;
                 porto.Iout=0;
                 PORTB= porto.B;
                 step= PAUSA;
             }
           }
           if(fh.START)
           {
             tstart=0;
           }
           else
           if(fil.START)
           {
              tstart++;
              if(tstart > DVESEC)
              {
                tstart=0;  
                step= READY;  
              }
           }
       }
       switch (step)
       {
        case INI: //po zapnuti napajeni
            step= READY;
    //        LEDZ=1;
            break;
        case READY: //pripraven 
            LEDZ=0;
            LEDC=0;
            if(fil.Li_Pb)
            {
                Uvyb=UBLiVYB;
                Unab=UBLiNAB;
                Tpvyb=TpLiVYB;
                Tpnab=TpLiNAB;
            }
            else
            {
                Uvyb=UBPbVYB;
                Unab=UBPbNAB;
                Tpvyb=TpPbVYB;
                Tpnab=TpPbNAB;
            }
                
            CCP2CONbits.CCP2M= 0x0;//vyp. RC1 
            CCP1CONbits.CCP1M= 0x0;//vyp. RC2 
            porto.B= PORTB;
            if(fh.I30_60_90)
            {
                ivyb++;
                ivyb %= 4;
                if(ivyb==0)
                dialvyb=0;
                    else
                dialvyb= ivyb*(ivyb-1) + 1; 
                porto.Iout= dialvyb;
            }
            if(fh.NAB1_2)
            {
                nab++;
                nab &=3;
                porto.NABout = nab;
            }
            PORTB= porto.B;
            if(fh.START)
            {
                 step= VYBIJI; 
            }
            break;    
         case VYBIJI:
             if(baterfil < Uvyb)
             {
                 porto.B= PORTB;
                 porto.Iout=0;
                 PORTB= porto.B;
                 step= VYBITA;
                 delay=0;
             }
             else
             {
                CCP2CONbits.CCP2M= 0x0;//vyp. RC1 
                CCP1CONbits.CCP1M= 0x0;//vyp. RC2 
                LEDC= LBLIK;
                LEDZ=0;
             }
            break;   
        case VYBITA:
            CCP2CONbits.CCP2M= 0x0;//vyp. RC1 
            CCP1CONbits.CCP1M= 0x0;//vyp. RC2 
            delay++;
            if(delay > Tpvyb)
            {
                delay=0; 
                step= NABIJI;
            }
            if(REDORA)
            {
                LEDC=LBLIK;
                LEDZ=LBLIK;
            }
            else
            {
                LEDC=LBLIK;
                LEDZ=0;
            }
        break;   
        case NABIJI:
            if(baterfil > Unab)
             {
                CCP2CONbits.CCP2M= 0x0;//vyp RC1 
                CCP1CONbits.CCP1M= 0x0;//vyp RC2 
                step= NABITA;
                delay=0;
                tcount=0;
                COUNTER = 1;                 
             }
            else
            {
                CCP2CONbits.CCP2M= 0xf;//PWM RC1 
                CCP1CONbits.CCP1M= 0xf;//PWM RC2 
                LEDC=LBLIK;
                LEDZ=LBLIK;
            }
        break;
        case NABITA:
            delay++;
            if(delay > Tpnab)
            {
                delay=0; 
                step= VYBIJI;
            }
            LEDZ=LBLIK;
            LEDC=0;
        break;
           case PAUSA:
             LED_PAUSA= LBLIK;  
           break;  
        default:
            LEDC= QBLIK;    //divny stav
             break;
       }     
       fh.B=0;
    }
   }   return (EXIT_SUCCESS);
}

