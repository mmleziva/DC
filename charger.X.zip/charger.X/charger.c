/* 
 * File:   DC.c
 * Author: mleziva
 *
 * Created on  2024
 */
#define TEST
#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
  #pragma config FOSC = XT
  #pragma config PWRTE = ON
  #pragma config WDTE = ON 
  #pragma config CP = ALL
#pragma config LVP = OFF
#pragma config BOREN = ON 
#pragma config CPD = OFF
#pragma config WRT = OFF

 // outputs
#define RESERVE     RC0
#define PWM_REGI    RC1	
#define RES2        RC2
#define RES3        RC3	
#define LED_PAUSA   RC4
#define COUNTER     RC5
    #define LEDZ        RC6
    #define LEDC        RC7
    #define LEDPORT PORTC 
    #define LEDORAN 0xc0 
#define LEDONEG (~LEDORAN) 
#define I30A     RB0
#define I60A     RB1
#define I90A     RB2
#define NAB1     RB3
#define NAB2     RB4
#define Pb_Li    RB5

//analog input channels
#define REGBAT    0
#define MERBAT    1

        //stavy programu
#define INI         0
#define READY      10
#define VYBIJI     20
#define VYBITA     30
#define NABIJI     40
#define NABITA     50
#define PAUSA      15


            //napeti

#define KBAT         (0x10000/(10*10*5))
#define UBLiVYB      (KBAT*95)// 10,0
#define UBPbVYB       (KBAT*88)// 9,3V
#define UBLiNAB      (KBAT*140)// 14,7V
#define UBPbNAB      (KBAT*140)// 14,7V



        //casy 1bit=2ms
#ifndef TEST
    #define TpLiVYB    (500*60*20)      //20min
    #define TpLiNAB    (500*60*30)      //30min.
    #define TpPbVYB    (500*60*10)      //10min.
    #define TpPbNAB    (500*60*60)      //60min.
#else
    #define TpLiVYB    (500*20)         //20sec
    #define TpLiNAB    (500*20)         //20sec
    #define TpPbVYB    (500*20)         //20sec
    #define TpPbNAB    (500*20)         //20sec
#endif

#define PULSEC      250            //500ms
#define SEC         500            //1s
#define DVESEC      1000            //2s
#define DESETSEC    5000            //10s
#define TIMINC      100            //200ms
#define PWMAX        251            //

//filtered dig.inputs
union
{
    uint8_t B;
    struct
    {
      uint8_t      : 1;    
      uint8_t       :1; 
      uint8_t START: 1; 
      uint8_t I30_60_90:1; 
      uint8_t NAB1_2:1; 
      uint8_t PAUSE: 1; 
      uint8_t Li_Pb: 1; 
      uint8_t       : 1; 
    };
} ai,  fil, fh,fd;  //vzorek, filtr, hrany vstupu

union
{
    uint8_t B;
    struct
    {
      uint8_t Iout : 3;    
      uint8_t NABout:2; 
    };
} porto;
        //16bit. slovo w=[H,L]
typedef union
{
    uint16_t w;
    struct
    {
        uint8_t L;
        uint8_t H;
    }  ;
}word;

_Bool PAUSE, LONGSTART, REDORA;// priznak pauza, dlouhe tlacitko start, stridani LED
_Bool ULOW, LBLIK, QBLIK, VYB, SIGNREG,SIGNORIG;
uint8_t in[8], set, res, film ;//prom. fitru
uint8_t step,stepold, k, j ,startime;//krok programu, predch. krok,.., citac prodlevy 50 ms 
uint8_t blik,ivyb,nab, dialnab, dialvyb;// odmer. blik.LED,predvolba vybijeni, predvolba nabijecek  , volba nabijecek, volba vybijecich odpory po 30A, pocet sepnutych nabijecek
uint16_t baterie,regulin,regold, baterfil, regulfil,regorig,zpozdeni, tstart, tcount,tnasta,timreg,timset,Uvyb,Unab;//;
uint32_t delay, Tpvyb, Tpnab;
int16_t dreg, dregor;

uint16_t adc_read(unsigned char channel)//mereni Adc
{  
ADCON0 = (channel << 3) + 0x41;		// !T enable ADC,  osc.8*Tosc
 //DelayUs(20); 
 j=3;
 while(j)
     j--;
 GO_DONE = 1;
 while(GO_DONE)
 continue;	// wait for conversion complete
 return (((uint16_t)ADRESH)<<8) + ADRESL;
}

void adc_filter(uint16_t *act,uint16_t *filt)//filtr hodnot, merenych Adc
{
    int16_t ax= (int16_t)((*act)>>4) - (int16_t)((*filt)>>4);
    *filt += (uint16_t)ax; 
}

inline void nastav(void)    //nastaveni vystupu
{
            if(fil.Li_Pb)
            {
                Uvyb=UBLiVYB;
                Unab=UBLiNAB;
                Tpvyb=TpLiVYB;
                Tpnab=TpLiNAB;
            }
            else
            {
                Uvyb=UBPbVYB;
                Unab=UBPbNAB;
                Tpvyb=TpPbVYB;
                Tpnab=TpPbNAB;
            }
            dreg= (int16_t)(regulfil- regold);
            if(dreg !=0)
            {      
                if(dreg < 0)SIGNREG=1; else SIGNREG=0;
                if((timreg == 0)|(SIGNREG != SIGNORIG))
                {
                    regorig= regulfil;
                    SIGNORIG= SIGNREG;
                    timreg=1;
                }
            }
            if(timreg > 50)//100ms
            {
                 timreg=0;
                 dregor= (int16_t)(regulfil- regorig);
                 if((dregor > 50)||(dregor < -50))
                    timset=1;                     
            }
            else
            if(timreg > 0)
                 timreg++;
            if(timset > DVESEC)
            {
              timset=0;  
            }
            else 
            if(timset > 0)
                timset++;        
            if(fh.I30_60_90)
            {
                ivyb++;
                if(ivyb > 3) ivyb=1 ;                
                dialvyb= ivyb*(ivyb-1) + 1; 
                porto.B= PORTB;
                porto.Iout= dialvyb;
                PORTB= porto.B;
                tnasta=1;
            }
            else
            if(fh.NAB1_2)
            {
                nab++;
                if(nab > 3) nab=1;
                dialnab=nab;
                porto.B= PORTB;
                porto.NABout = dialnab;
                PORTB= porto.B;
                tnasta=1;
            }
            else
            if(tnasta > DVESEC)
            {
                    tnasta=0;
            }
            else 
            if(tnasta > 0)
            {                
                    tnasta++;
            }
            else
            if(timset > 0)
            {
                porto.B= PORTB;
                porto.Iout= 0;
                porto.NABout=dialnab;
                PORTB= porto.B;
                CCPR2L=regulfil>>8;//t
                CCPR1L=CCPR2L;// reservni PWM
                CCP2CONbits.CCP2M= 0xf;///PWM RC1 
                CCP1CONbits.CCP1M= 0xf;//PWM RC2 
            }
            else
            {
                porto.B= PORTB;
                porto.Iout= 0;
                porto.NABout=0;
                PORTB= porto.B;
                CCP2CONbits.CCP2M= 0x0;//vyp. RC1 
                RC1=0;
                CCP1CONbits.CCP1M= 0x0;//vyp. RC2 
                RC2=0;
            }
}

int main(int argc, char** argv)
{
        //config
   PORTC=0x0; 
   TRISC=0x0;     //outs enable
   PORTB= 0b00000000;
   TRISB= 0b11100000;//
   OPTION_REGbits.nRBPU=1;//no pull up
   ADCON1bits.ADFM= 0;//left just. ADC
   step=INI;
    //init dig. filters
   ADCON1bits.PCFG=0x0e;//RA0 analog,RA1..RA7 digital
   ai.B= PORTA;
   ADCON1bits.PCFG=0x04;//RA0,RA1,RA3 analog,RA2, RA4..RA7 digital
   ai.Li_Pb= Pb_Li;
   film= ai.B; //inverted inputs
   for (j=0; j<8; j++)
   {
           in[j]= film;
   }
   fil.B= film;
   fh.B=0;
   
    //init adc's
   baterfil= adc_read(REGBAT);
   regulfil= adc_read(MERBAT);
   CCPR2L=0;
   CCPR1L=0;
   T2CONbits.T2CKPS= 1;//prescaller=4
   PR2=PWMAX-1;   //250*4=1000us TMR2 period
   T2CONbits.TMR2ON= 1;//start T2   
   TMR1=-2000;
   TMR1ON=1;
   //infinited cycle
   while(1)
   {    
     CLRWDT();  //clear watchdog timer
     if(TMR1IF)//2ms cyklus
     {
         TMR1=-2000;
         TMR1IF =0;
                   //digital filters Td=8*2=16ms
       k++;
       k %=8;
       ADCON1bits.PCFG=0x0e;//RA0 analog,RA1..RA7 digital
       ai.B= PORTA;
       ADCON1bits.PCFG=0x04;//RA0,RA1,RA3 analog,RA2, RA4..RA7 digital
       ai.Li_Pb= Pb_Li;
       in[k]= ai.B;
       set=0xff;
       res=0;
       for (j=0; j<8; j++)
       {
           set &= in[j];   //all 8 last 5ms samples must be 1 for set to 1  
           res |= (in[j]); //all 8 last 5ms samples must be 0 for reset to 0  
       }
       fil.B= ((~film) & set) | (film & (res));
       fh.B= ((~film) & fil.B ); //rise edge 
       film= fil.B;// memory     
       regulin= adc_read(REGBAT);
       baterie= adc_read(MERBAT);
       adc_filter( &regulin,&regulfil);
       adc_filter( &baterie,&baterfil);
       if(blik==0)REDORA= !REDORA;  //prepinani bitu po 256x2=512ms kvuli preblikani rude a oranz led 
       LBLIK= ((blik & 0x80) != 0);//priznak blikani
   //    QBLIK= ((blik & 0x20) != 0);//priznak blikani 4x rychleji
       blik++;  
                        //prodleva po startu
       if(startime< TIMINC)
       {
         startime++;
         step= INI;
       }     
   
                //vyber akce dle aktualniho stavu
       if(COUNTER)      //puls do pocitadla
       {
           tcount++;
           if(tcount > PULSEC)
           {    
               COUNTER = 0;
               tcount=0;
           }
       }
       if(step > READY)
       {
           if(fh.PAUSE) //hrana tlacitka pausa
           {
             if(step==PAUSA)    //ukonceni pausy
             {
                 step= stepold;
                 LED_PAUSA = 0;
             }
             else
             {          //zacatak pausy
                 stepold= step;
                 ivyb=0; nab=0;
                 step= PAUSA;
             }
           }
           else
           if(fil.START)    
           {
              tstart++;
              if(tstart > DVESEC)
              {                     //konec nabijeni
                tstart=0;  
                step= READY;  
              }
           }
           else
               tstart=0;
       }
       switch (step)
       {
        case INI: //po zapnuti napajeni
            step= READY;
             break;
        case READY: //pripraven             
            if(fh.START)
            {
                 step= VYBIJI; 
            }
            else
            {
                LEDZ=1;
                LEDC=0;
                nastav();
            }
            break;    
         case VYBIJI:
             if(baterfil < Uvyb)
             {
                 step= VYBITA;
                 delay=0;
             }
             else
             {
                porto.B= PORTB;
                porto.Iout=dialvyb;
                porto.NABout=0;
                PORTB= porto.B;
                CCP2CONbits.CCP2M= 0x0;//vyp. RC1 
                CCP1CONbits.CCP1M= 0x0;//vyp. RC2 
                LEDC= LBLIK;
                LEDZ=0;
             }
            break;   
        case VYBITA:
            if(delay > Tpvyb)
            {
                delay=0; 
                step= NABIJI;
            }
            else
            {
                if(REDORA)
                {
                    LEDC=LBLIK;
                    LEDZ=LBLIK;
                }
                else
                {
                    LEDC=LBLIK;
                    LEDZ=0;
                }
                porto.B= PORTB;
                porto.Iout=0;
                porto.NABout=0;
                PORTB= porto.B;
                CCP2CONbits.CCP2M= 0x0;//vyp. RC1 
                CCP1CONbits.CCP1M= 0x0;//vyp. RC2 
                delay++;
            }
        break;   
        case NABIJI:
            if(baterfil > Unab)
            {
                step= NABITA;
                delay=0;
                tcount=0;
                COUNTER = 1;                 
             }
           else
            {
                LEDC=LBLIK;
                LEDZ=LBLIK;
                porto.B= PORTB;
                porto.Iout=0;
                porto.NABout=dialnab;
                PORTB= porto.B;
                CCP2CONbits.CCP2M= 0xf;//PWM RC1 
                CCP1CONbits.CCP1M= 0xf;//PWM RC2 
            
            }
        break;
        case NABITA:
            if(delay > Tpnab)
            {
                delay=0; 
                step= VYBIJI;
            }
            else
            {
                LEDZ=LBLIK;
                LEDC=0;
                porto.B= PORTB;
                porto.Iout=0;
                porto.NABout=0;
                PORTB= porto.B;
                CCP2CONbits.CCP2M= 0x0;//vyp. RC1 
                RC1=0;
                CCP1CONbits.CCP1M= 0x0;//vyp. RC2 
                RC2=0;
                delay++;
            }
        break;
        case PAUSA:            
             LED_PAUSA= LBLIK;
             LEDZ=0;
             LEDC=0;
             nastav();
        break;  
        default:
            LEDC= QBLIK;    //divny stav
             break;
       }     
       fh.B=0;
       regold= regulin;
    }
   }   return (EXIT_SUCCESS);
}

