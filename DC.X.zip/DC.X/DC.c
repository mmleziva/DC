/* 
 * File:   solderwave.c
 * Author: mleziva
 *
 * Created on 12. ?�jna 2023, 16:03
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#pragma config FOSC = XT
//#pragma config FOSC = HS    //!t
#pragma config LVP = OFF
#pragma config PWRTE = ON 
//#pragma config PWRTE = OFF //!t
#pragma config BOREN = ON
#pragma config WDTE = ON  
//#pragma config WDTE = OFF  //!t
#pragma config CPD = OFF
#pragma config WRT = OFF
//#pragma config DEBUG = 0   //!t


 // outputs
#define RESERVE    RC0
#define PWM_VPRED   RC1	
#define PWM_VZAD    RC2
#define BEZP_RELE   RC3	
#define VPRED       RC4
#define VZAD        RC5
#define LEDZ        RC6
//#define LEDZ        RE0 //!t
#define LEDC        RC7
//#define LEDC        RE1 //!t
#define LEDPORT PORTC 
//#define LEDPORT PORTE   //!t
#define LEDORAN 0xc0 
//#define LEDORAN 0x3 //!t 
#define LEDONEG (~LEDORAN) //!t
//#define OUT_START  RA4
#define NAP_OCHRA  RB2

//analog input channels
#define AKCELERATOR 0
#define U_BATERIE   1 
//#define U_BATERIE   3 //!t
#define U_FUSE      4

        //stavy programu
#define INI         0
#define READY       2
#define READY_VZAD 4
#define VYBITA      8
#define GOVPRED    10
#define PWMVPRED   12
#define GOVZAD     20
#define PWMVZAD    22
#define BRZDENI    30
#define PO_NARAZU  40
#define OCHR_BAT   50
#define PREBITA    55
#define FUSE        60


            //napeti
#define PWMAX      250
#define PWMIN      (((PWMAX)*15)/100)   //15% PWMAX
#define AKCMIN    (256/5)  //bitu /V 
#define AKCMIN16b (0x10000/5)  //bitu /V 
#define AKCMAX    ((256*4)/5)   //bitu/4V
#define AKCMUL     (((PWMAX - PWMIN)*5)/(4-1))
#define BRZDMIN      (((PWMAX)*20)/100)   //20% PWMAX
#define BRZDMUL     (((PWMAX - BRZDMIN)*5)/(4-1))
//#define KBAT         (0x10000/(10*10*5))
#define KBAT         (61826/(10*10*5))  //(15V/15,9V)*(0x10000/(10*10*5)

//#define KBAT         (0x10000/200)  //!t
#define UBATOCH      (KBAT*85)//8,5V 
#define UBATVYB      (KBAT*114)// 11,4V
#define UBATOK       (KBAT*125)// 12,5V
#define UBATLOD      (KBAT*145)// 14,5V
#define UBATHOD      (KBAT*150)// 15V
#define UBATPRE      (KBAT*160)// 16V
#define FUSEMIN      (KBAT*60)//6V 

        //casy 1bit=2ms
#define ZPOZBAT    15000      //30s
#define TIMINC     50        //100ms
#define TRAMPINC   (1000/(PWMAX-PWMIN))  //pridavani plynu
#define TIMAX      (150000UL)//1000ms *60 *5= 5 min.
#define NARAM      500  //1s

//#define NUCENA

//filtered dig.inputs
union
{
    uint8_t B;
    struct
    {
      uint8_t NARAZ: 1;    
      uint8_t BRZDA: 1; 
      uint8_t       : 1; 
      uint8_t       : 1; 
      uint8_t        :1; 
      uint8_t START_IN: 1; 
      uint8_t       : 1; 
      uint8_t       : 1; 
    };
} ai,  fil, fh,fd;  //vzorek, filtr, hrany vstupu

        //16bit. slovo w=[H,L]
typedef union
{
    uint16_t w;
    struct
    {
        uint8_t L;
        uint8_t H;
    }  ;
}word;

_Bool PAUSE;// priznak pauza
_Bool POJISTKA;
_Bool ULOW, LBLIK, QBLIK, AKCEL_SEP;
uint8_t in[8], set, res, film ;//prom. fitru
uint8_t step,stepold, k, j ,lt, prodleva,probrzd, startime;//krok programu, predch. krok,.., citac prodlevy 50 ms 
uint8_t plyn,blik;//prepoctena hod. akc.do  pwm,  odmer. blik.LED
uint16_t baterie,akcel,fuse,baterfil, akcelfil,fusefil,zpozdeni, naratim;;
uint32_t timvyp;

uint16_t adc_read(unsigned char channel)//mereni Adc
{  
ADCON0 = (channel << 3) + 0x81;		// !T enable ADC,  osc.8*Tosc
 //DelayUs(20); 
 j=3;
 while(j)
     j--;
 GO_DONE = 1;
 while(GO_DONE)
 continue;	// wait for conversion complete
 return (((uint16_t)ADRESH)<<8) + ADRESL;
}

void adc_filter(uint16_t *act,uint16_t *fil)//filtr hodnot, merenych Adc
{
    int16_t ax= (int16_t)((*act)>>4) - (int16_t)((*fil)>>4);
    *fil += (uint16_t)ax; 
}

uint8_t pwmakc(uint16_t uak)// prepocet napeti akceleratoru na pwm 
{
    word uacc, resw;
    uint8_t huac, result, difhu;
    uacc.w= uak;
    huac= uacc.H;
    if(huac <= AKCMIN)
        result=0;
    else if(huac >= AKCMAX)
        result= PWMAX;
    else
    {
        difhu = huac-AKCMIN;
        resw.w= AKCMUL * difhu;
        result=resw.H +PWMIN;
    }
    return result;
}

uint8_t pwmbrzd(uint16_t uak)// prepocet napeti akceleratoru na pwm brzdeni
{
    word uacc, resw;
    uint8_t huac, result, difhu;
    uacc.w= uak;
    huac= uacc.H;
    if(huac <= AKCMIN)
        result= BRZDMIN;
    else if(huac >= AKCMAX)
        result= PWMAX;
    else
    {
        difhu = huac-AKCMIN;
        resw.w= BRZDMUL * difhu;
        result=resw.H +BRZDMIN;
    }
    return result;
}

int main(int argc, char** argv)
{
        //config
   PORTC=0x0; 
   TRISC=0x0;     //outs enable
   TRISBbits.TRISB2=0;
  //  TRISEbits.TRISE0=0;//!t
  //  TRISEbits.TRISE1=0;//!t
   //OUT_START=1;
   //PORTA=0x10;
   PORTA= 0b00011100;
   OPTION_REGbits.nRBPU=0;// pull up
   ///TRISAbits.TRISA4=0;     //OUT_START out enable
   TRISA= 0b11100011;
   ADCON1bits.ADFM= 0;//left just. ADC
   CCPR2L=0;
   CCPR1L=0;
   CCP2CONbits.CCP2M= 0xf;//PWM RC1 VPRED
   CCP1CONbits.CCP1M= 0xf;//PWM RC2 VZAD
   T2CONbits.T2CKPS= 1;//prescaller=4
   PR2=PWMAX;   //250*4=1000us TMR2 period
   T2CONbits.TOUTPS=1;//postscalller=2, T2IF 2ms
   T2CONbits.TMR2ON= 1;//start T2   
   step=INI;
   
    //init dig. filters
   ai.B= ~PORTB;
   film= ai.B; //inverted inputs
   for (j=0; j<8; j++)
   {
           in[j]= film;
   }
   fil.B= film;
   fd.B=0;  //edges
   fh.B=0;
   
    //init adc's
   akcelfil= adc_read(AKCELERATOR);
   baterfil= adc_read(U_BATERIE);
   fusefil= adc_read(U_FUSE);
   
   //infinited cycle
   while(1)
   {    
     CLRWDT();  //clear watchdog timer
     if(TMR2IF)//2ms cyklus
     {
       TMR2IF=0;
                   //digital filters Td=8*2=16ms
       k++;
       k %=8;
       ai.B= ~PORTB;    //inverted inputs
       in[k]= ai.B;
       set=0xff;
       res=0;
       for (j=0; j<8; j++)
       {
           set &= in[j];   //all 8 last 5ms samples must be 1 for set to 1  
           res |= (in[j]); //all 8 last 5ms samples must be 0 for reset to 0  
       }
       fil.B= ((~film) & set) | (film & (res));
       fd.B= fd.B |(film & (~fil.B) );//fall edge        
       fh.B= fh.B |((~film) & fil.B ); //rise edge 
       film= fil.B;// memory     
       akcel= adc_read(AKCELERATOR);
       baterie= adc_read(U_BATERIE);
       fuse= adc_read(U_FUSE);
       adc_filter( &akcel,&akcelfil);
       adc_filter( &baterie,&baterfil);
       adc_filter( &fuse,&fusefil);
       LBLIK= ((blik & 0x80) != 0);//priznak blikani
       QBLIK= ((blik & 0x20) != 0);//priznak blikani 4x rychleji
       blik++;
       if(probrzd >0)//prodleva 8ms pro vypinani rele
       {
        probrzd++;
        if(probrzd >4)
           probrzd=0;
       }
       AKCEL_SEP=(akcelfil > AKCMIN16b);
       BEZP_RELE= AKCEL_SEP;     
            
                //prioritni akce
       if(AKCEL_SEP && (step != FUSE)&& (fusefil< FUSEMIN)) //sledovani stavu silove pojistky
       {
             LEDPORT &= LEDONEG;      //zhasni obe LED
             step= FUSE;
             VPRED=0;
             VZAD =0;   
             probrzd=1; //zapina odpocitani prodlevy pro vypinani rele
             LEDC=1;  //rozsvit cervenou
       }
       else
     //  if(fh.NARAZ && (step != PO_NARAZU))  //pri narazu 
       if(fh.NARAZ && ((step == READY_VZAD)||(step == GOVZAD)|| (step == PWMVZAD)))  //pri narazu 
       {
         fh.NARAZ= 0;  
         VZAD=0;
         probrzd=1;//zapina odpocitani prodlevy pro vypinani rele
         CCPR1L=0;
         step= PO_NARAZU; 
       }    
       else 
       if(AKCEL_SEP && (baterfil < UBATOCH) && (step != OCHR_BAT))   //podpetova ochrana baterie
       {
             VZAD=0;
             VPRED=0;  
             probrzd=1;//zapina odpocitani prodlevy pro vypinani rele
             step= OCHR_BAT;
       }
       else
       if(fh.BRZDA && (step != BRZDENI))     //pouziti  brzdy
       {
           fh.BRZDA=0;
           probrzd=1;//zapina odpocitani prodlevy pro vypinani rele
           VPRED=0;
           VZAD =0;   
           fh.START_IN=0;
           LEDPORT &= LEDONEG;//led zhasnuty
           LEDC=1;
           step= BRZDENI;           
       }
       else
       if((baterfil > UBATPRE)&& (step != PREBITA))
       {
           stepold= step;
           VPRED=0;
           VZAD =0;   
           probrzd=1;
           step= PREBITA;
       }
       else
       plyn = pwmakc(akcelfil);// jinak se meri pedal plynu
       if(baterfil > UBATHOD)   //napetova ochrana
       {
           NAP_OCHRA=1;
       }
       else if(baterfil < UBATLOD)
       {
           NAP_OCHRA=0;
       };
       if(zpozdeni > ZPOZBAT)// po prodleve 30s
       {
           zpozdeni= 0;
           if(baterfil< UBATVYB)
           {
               ULOW=1;  //nastav priznak vybite baterie
           }
       }
       else 
       {
         if(zpozdeni > 0)
         zpozdeni ++; 
       }
       
       if( AKCEL_SEP )   //test oddaleni vypnuti elektroniky
       {
           timvyp=0;
       }
       else 
       if(timvyp > TIMAX)// test vypnuti po 5 minutach
       {
       //  OUT_START=0;
              PORTA=0x0;
        // TRISAbits.TRISA4=1;
              TRISA=0b11111111;
       }
       else
       {
      //    TRISAbits.TRISA4=0;
      //     OUT_START=1;
          //   PORTA=0x10;
           PORTA=0b00011100;
           TRISA=0b11100011;
           timvyp++;
       }    
                        //prodleva po startu
       if(startime< TIMINC)
       {
         startime++;
         step= INI;
       }      
                //vyber akce dle aktualniho stavu
       switch (step)
       {
        case INI: //po zapnuti napajeni
            step= READY;
            LEDZ=1;
            break;
        case READY: //pripraven pro rozjezd
            if(fh.START_IN)     //startovaci spinac
            {
             LEDPORT |= LEDORAN;   //rozsviti zelenou i rudou LED
             step= READY_VZAD;//a prepne na pripraven pro zpatecku
            }
            else if(plyn > 0)
            {
             step= GOVPRED;   
            }
            else
            if(ULOW)    //blikani cervene LED  pri vybite bat.
            {
              LEDPORT &= LEDONEG;//led zhasnuty
              step= VYBITA;
     //         LEDC= LBLIK;  
   //           LEDZ=0;
            }
            fh.START_IN=0;
            break;
        case READY_VZAD: //pripraven pro zpatecku
#ifdef NUCENA            
            if(!fil.START_IN)
            {
           //  LEDC=0;
             LEDPORT &= LEDONEG;//led zhasnuty
             step= READY;
             LEDZ=1;
            }
#else
            if(fh.START_IN)
            {
          //   LEDC=0;
             LEDPORT &= LEDONEG;//oranz zhasnuta
             LEDZ=1;
             step= READY;
            }
#endif
            else 
            if(plyn > 0)
            {
             step= GOVZAD;   
            }
            else
            if(ULOW)    //blikani cervene pri vybite bat.
            {                
              LEDPORT &= LEDONEG;//oranz zhasnuta
              step= VYBITA;
    //          LEDC= LBLIK;   
            }
            fh.START_IN=0;
            break;
       case VYBITA:
            if(!ULOW)
            {
               LEDPORT &= LEDONEG;//oranz zhasnuta
               LEDZ=1;
               step= READY;               
            }
            else 
                LEDC= LBLIK;
            break;   
       case GOVPRED: //prodleva 100ms pred rozjezdem
            prodleva++;
            if(prodleva> TIMINC)
            {
                prodleva=0;
                VZAD=0;
                VPRED= 1;
                step = PWMVPRED;
                CCPR2L= PWMIN;
            }
            break;
        case PWMVPRED: //plyn vpred
             if(plyn < PWMIN)  //po uvolneni plynu navrat na ready
             {
                 CCPR2L=0;
                 fh.START_IN= 0;
                 VPRED=0;
                 step= READY;   
                 LEDPORT &= LEDONEG;//oranz zhasnuta
                 LEDZ= 1;
                 zpozdeni=1; //zacina pocitat zpozdeni pro test vybite bat.  
             }
             else
             {
              if(plyn > CCPR2L)//POSTUPNE PRIDAVA PLYN
              {
                 lt++;
                 if(lt > TRAMPINC)
                 {
                     lt=0;
                     CCPR2L++;
                 }
              }
              else
                 CCPR2L= plyn;  //nepridava plyn, resp. okamzite ubira
              ULOW= 0;
              probrzd=1;
              if(CCPR2L >= PWMAX)// plyn nadoraz neblika
                  LEDZ=1;
              else
                  LEDZ= QBLIK;
             }
             break;

        case GOVZAD: //prodleva 50ms pred zpateckou
            prodleva++;
            if(prodleva> TIMINC)
            {
                prodleva=0;
                VPRED=0;
                VZAD=1;
                step = PWMVZAD;
                CCPR1L= PWMIN;
            }
            break;
        case PWMVZAD://plyn zpatecky
             if(plyn < PWMIN)
             {
                 CCPR1L=0;
                 VZAD=0;
                 fh.START_IN= 0;
                 step= READY_VZAD;  
                 LEDPORT |= LEDORAN;
                 zpozdeni=1;   //zacina pocitat zpozdeni pro test vybite bat.
             }
#ifdef NUCENA
             else
                 if(!fil.START_IN)
                 {
                     CCPR1L=0;
                     VZAD=0;
                     LEDPORT &= LEDONEG;
                     LEDZ=1;
                     step= READY;  
                     zpozdeni=1;
                 }
#endif
             else
             {
              if(plyn > CCPR1L)//POSTUPNE PRIDAVA PLYN
              {
                 lt++;
                 if(lt > TRAMPINC)
                 {
                     lt=0;
                     CCPR1L++;
                 }
              }
              else
                 CCPR1L= plyn; //nepridava plyn, resp. okamzite ubira
              probrzd= 1;   //zapina odpocitani prodlevy pro vypinani rele
              ULOW= 0;
              if(CCPR1L >= PWMAX)// plyn nadoraz:LED sviti trvale
                     LEDPORT |= LEDORAN;
              else                 
              {
                  if(QBLIK)      //obe led blikaji
                        LEDPORT |= LEDORAN;//oranz sviti
                  else
                        LEDPORT &= LEDONEG;//oranz zhasnuta
               }
             }
             break;
         
        case BRZDENI: //
            if(fh.START_IN) //konec  brzdy
            {
                fh.START_IN= 0;
                CCPR1L= 0;
                CCPR2L= 0;
                LEDPORT &= LEDONEG;//led zhasnuty
             //   LEDC=0;
                LEDZ=1;
                step= READY;
            }
            else
            if(probrzd==0)    //brzdeni akceleratorem
            {
                CCPR1L= pwmbrzd(akcelfil);
                CCPR2L= CCPR1L;
            }
            break;
        case PO_NARAZU: //
            if(naratim > NARAM )//po uplynuti 1s
            {
              naratim=0;
              VPRED=0;
              CCPR2L= 0;
              probrzd=1;    //zapina odpocitani prodlevy pro vypinani rele
              fh.NARAZ=0;    //nuluje znova hranu koncaku
              LEDPORT &= LEDONEG;//obe LED zhasnuty
              LEDZ= 1;
              step= READY;
            }
            else 
            if(probrzd==0)// vpred na plny plyn
            {   
              VPRED=1;
              CCPR2L = PWMAX;
              naratim++;
             } 
             break;

        case OCHR_BAT:
            if(baterfil> UBATOK)//testuje napeti bat. OK
            {
                   step= READY;
                   LEDPORT &= LEDONEG;//obe LED zhasnuty
                   LEDZ= 1;
   //                LEDC=0;
                   CCPR1L=0;
                   CCPR1L=0;
            }        
            else        //brzdeni naplno
            {
             LEDC= LBLIK;   
             if((CCPR1L != PWMAX)&&(probrzd==0))
               CCPR1L= PWMAX;
             if((CCPR2L != PWMAX)&&(probrzd==0))
               CCPR2L= PWMAX;   
            }
            break;
        case PREBITA:
            if(baterfil< UBATPRE)
            {
                CCPR1L=0;
                CCPR1L=0;
                if((stepold == GOVZAD)||(stepold == READY_VZAD)||(stepold == PWMVZAD))
                {
                    LEDPORT |= LEDORAN;//oranz sviti
                    step= READY_VZAD;
                }
                else
                {
                   LEDPORT &= LEDONEG;//obe LED zhasnuty
                   LEDZ= 1;
                   step= READY;
                }
            }
            else
            {
             if((CCPR1L != PWMAX)&&(probrzd==0))
               CCPR1L= PWMAX;
             if((CCPR2L != PWMAX)&&(probrzd==0))
               CCPR2L= PWMAX;
            }
            break;               
        case FUSE: //  spalena silova pojistka  
            if(probrzd!=0)//pro jistotu pauza na vyp. rele
                break;
            else
            if(fusefil > FUSEMIN)//napeti za sil. poj. obnoveno
            {
                CCPR1L= 0;
                CCPR2L= 0;
                LEDPORT &= LEDONEG;//obe LED zhasnuty
                LEDZ= 1;
         //       LEDC=0;
                step= READY;
            }
            else
            if(plyn>0)
            {                   //brzdeni pri vypadku sil. pojistky
                  CCPR1L= PWMAX;
                  CCPR2L= PWMAX;   
             }
            else
            {
                 CCPR1L= 0;
                 CCPR2L= 0;
            }
            break;

             
        default:
             break;
       }     
     }
   }
   return (EXIT_SUCCESS);
}

