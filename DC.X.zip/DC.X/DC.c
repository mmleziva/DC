/* 
 * File:   solderwave.c
 * Author: mleziva
 *
 * Created on 12. ?�jna 2023, 16:03
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#pragma config FOSC = XT
#pragma config LVP = OFF
#pragma config PWRTE = ON
#pragma config BOREN = ON
#pragma config WDTE = ON
#pragma config CPD = OFF
#pragma config WRT = OFF


 // outputs
#define RESERVE    RC0
#define PWM_VPRED   RC1	
#define PWM_VZAD    RC2
#define BEZP_RELE   RC3	
#define VPRED       RC4
#define VZAD        RC5
#define LEDZ        RC6
#define LEDC        RC7
#define OUT_START  RA4
#define NAP_OCHRA  RB2

//analog input channels
#define AKCELERATOR 0
#define U_BATERIE   3//1 //!t
#define U_FUSE      4

#define READY       2
#define READY_VZAD 4
#define FUSE        6
#define GOVPRED    10
#define GOVZAD     20
#define PO_NARAZU  30
#define BRZDENI    40

#define PWMAX      250
#define PWMIN      ((250*15)/100)
#define AKCMIN    (256/5)//bit /V
#define AKCMAX    ((256*4)/5)
#define AKCMUL     (((PWMAX - PWMIN)*5)/(4-1))
#define FUSEMIN    0x8000

//filtered inputs
union
{
    uint8_t B;
    struct
    {
      uint8_t NARAZ: 1;    
      uint8_t BRZDA: 1; 
//      uint8_t START_IN: 1; 
      uint8_t       : 1; 
      uint8_t       : 1; 
      uint8_t        :1; 
      uint8_t START_IN: 1; 
      uint8_t       : 1; 
      uint8_t       : 1; 
    };
} ai,  fil, fh,fd;  //vzorek, filtr, hrany vstupu

typedef union
{
    uint16_t w;
    struct
    {
        uint8_t L;
        uint8_t H;
    }  ;
}word;

_Bool PAUSE;// priznak pauza
_Bool POJISTKA;
uint8_t in[8], set, res, film ;//prom. fitru


uint8_t step, k, j ,lt, prodleva;//krok programu, mereni cyklu, odmer. blik.LED
uint8_t miniakc=52, maxakc=205,tmp=5,plyn;
//uint8_t baterie,vybito;
uint16_t baterie,akcel,fuse,baterfil, akcelfil,fusefil;

uint16_t adc_read(unsigned char channel)
{  
ADCON0 = (channel << 3) + 0x81;		// !T enable ADC,  osc.8*Tosc
 //DelayUs(20); 
 j=2;
 while(j)
     j--;

 GO_DONE = 1;
 while(GO_DONE)
 continue;	// wait for conversion complete
 return (((uint16_t)ADRESH)<<8) + ADRESL;
}

void adc_filter(uint16_t *act,uint16_t *fil)
{
    int16_t ax= (int16_t)((*act)>>4) - (int16_t)((*fil)>>4);
    *fil += (uint16_t)ax; 
}

uint8_t pwmakc(uint16_t uak)// prepocet napeti akceleratoru na pwm 
{
    word uacc, resw;
    uint8_t huac, result, difhu;
    uacc.w= uak;
    huac= uacc.H;
    if(huac <= AKCMIN)
        result=0;
    else if(huac >= AKCMAX)
        result= PWMAX;
    else
    {
        difhu = huac-AKCMIN;
        resw.w= AKCMUL * difhu;
        result=resw.H +PWMIN;
    }
    return result;
}

int main(int argc, char** argv)
{
        //config
   PORTC=0x0; 
   TRISC=0x0;     //outs enable
   //TRISBbits.TRISB2=0;
   TRISBbits.TRISB5=0;
   OUT_START=1;
   OPTION_REGbits.nRBPU=0;// pull up
   TRISAbits.TRISA4=0;     //OUT_START out enable
   ADCON1bits.ADFM= 0;//left just. ADC
   CCP2CONbits.CCP2M= 0xf;//PWM RC1 VPRED
   CCP1CONbits.CCP1M= 0xf;//PWM RC2 VZAD
   T2CONbits.T2CKPS= 1;//prescaller=4
   PR2=250;   //250*4=1000us TMR2 period
   T2CONbits.TOUTPS=1;//postscalller=2, T2IF 2ms
   T2CONbits.TMR2ON= 1;//start T2   
   step=0;
    //ini filters
   ai.B= ~PORTB;
   film= ai.B; //inverted inputs
   for (j=0; j<8; j++)
   {
           in[j]= film;
   }
   fil.B= film;
   fd.B=0;  //edges
   fh.B=0;
   ADCON1bits.ADFM= 1;      //left justified
   akcelfil= adc_read(AKCELERATOR);
   baterfil= adc_read(U_BATERIE);
   fusefil= adc_read(U_FUSE);

        //infinited cycle
   while(1)
   {    
     CLRWDT();  //clear watchdog timer
     if(TMR2IF)//5ms
     {
       TMR2IF=0;
                   //filters Td=8*5=40ms
       k++;
       k %=8;
       ai.B= ~PORTB;    //inverted inputs
       in[k]= ai.B;
       set=0xff;
       res=0;
       for (j=0; j<8; j++)
       {
           set &= in[j];   //all 8 last 5ms samples must be 1 for set to 1  
           res |= (in[j]); //all 8 last 5ms samples must be 0 for reset to 0  
       }
       fil.B= ((~film) & set) | (film & (res));
       fd.B= fd.B |(film & (~fil.B) );//fall edge        
       fh.B= fh.B |((~film) & fil.B ); //rise edge 
       film= fil.B;// memory     
       akcel= adc_read(AKCELERATOR);
       baterie= adc_read(U_BATERIE);
       fuse= adc_read(U_FUSE);
       adc_filter( &akcel,&akcelfil);
       adc_filter( &baterie,&baterfil);
       adc_filter( &fuse,&fusefil);
       plyn = pwmakc(akcelfil);
             //cycles 
    /*   
       if(omez_Uc())
           vypnuti();
       if(akcelerator > miniakc)    
       {
           if(fil.START_IN)
               jed_vzad();
           else
               jed_vpred();
       }
       if(POJISTKA)
           bezp_brzda();
       baterie--;
       if(baterie==0)
       {
           if(napeti_B < (0x300+229))
               vybito++;
           else vybito=0;
           if(vybito==255)
               vybita_bat();
       }
       if(fil.BRZDA)
           brzdeni();
       if(fil.NARAZ)
           reverzuj();
     */ 
       if(fusefil< FUSEMIN) 
       {
           LEDC=1;
           LEDZ=0;
           step= FUSE;
           VPRED=0;
           VZAD =0;           
       }
       else 
       if(fd.BRZDA)
       {
           fd.BRZDA=0;
           step= BRZDENI;           
       }       
       switch (step)
       {
        case READY: //
            if(fh.START_IN)
            {
             fh.START_IN=0;
             LEDC=1;
             step= READY_VZAD;
            }
            else if(plyn > 0)
            {
             step= GOVPRED;   
            }
             break;
        case READY_VZAD: //
            if(fh.START_IN)
            {
             fh.START_IN=0;
             LEDC=0;
             step= READY;
            }
            else if(plyn > 0)
            {
             step= GOVZAD;   
            }
             break;
        case GOVPRED: //
            prodleva++;
            if(prodleva> 50)
            {
                prodleva=0;
                VZAD=0;
                VPRED= 1;
                step = (GOVPRED+2);
                CCPR1L= PWMIN;
            }
            break;
        case GOVZAD: //
            prodleva++;
            if(prodleva> 50)
            {
                prodleva=0;
                VPRED=0;
                VZAD= 1;
                step = (GOVZAD+2);
            }
            break;
         case (GOVPRED+2):
             if(plyn < PWMIN)
             {
                 step= READY;
                 
             }
             else
             if(plyn > CCPR1L)
             {
                 k++;
                 if(k>10)
                 {
                     k=0;
                     CCPR1L++;
                 }
             }
             else
                 CCPR1L= plyn;
             
             break;
        case PO_NARAZU: //
             break;
        case BRZDENI: //
             break;
        case FUSE: //    
            if(fusefil > FUSEMIN)
            {
                CCPR1L= 0;
                CCPR2L= 0;
                LEDC=0;
                LEDZ=1;
                step= READY;
            }
            else
            if(plyn>0)
            {
                  CCPR1L= PWMAX;
                  CCPR2L= PWMAX;   
             }
            else
            {
                 CCPR1L= 0;
                 CCPR2L= 0;

            }
            break;
                default:
             break;
       }     
     }
   }
   return (EXIT_SUCCESS);
}

